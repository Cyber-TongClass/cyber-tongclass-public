# Terminal Adventure

欢迎来到终端小冒险。

你会用命令行完成几件事情：

1. 浏览目录和文件。
2. 找到散落在不同房间里的线索。
3. 从日志里统计错误。
4. 从 CSV 中找出分数最高的人。
5. 写一个脚本，把上面的流程自动化。

建议从这些命令开始：

```bash
pwd
ls -la
cat README.md
find . -type f
```

## 课后练习

### 基础操作

1. 进入 `terminal-adventure` 目录，运行 `pwd`，确认当前路径。
2. 用 `ls`、`ls -a`、`ls -l` 分别查看目录，说明 `.secrets` 为什么一开始看不到。
3. 在 `scratch` 目录里创建 `draft.txt`，写入两行文本，再复制、改名、移动、删除一次。
4. 用 `file` 查看 `README.md`、`logs/dragon.log`、`data/scores.csv` 的类型。

### 搜索和统计

1. 用 `grep` 找到真正的 key。提示：可以搜索 `key=`，不要被普通的 `key` 单词骗到。
2. 用 `grep -n` 找到所有 `ERROR` 行，并显示行号。
3. 用管道统计 `ERROR` 的行数。
4. 用 `find` 找出所有 `.csv` 文件。
5. 用 `find` 和 `xargs` 统计 `rooms` 下所有 `.txt` 文件的行数。

### CSV 和脚本

1. 用 `cut` 取出 `scores.csv` 的名字列。
2. 用 `awk` 输出名字和分数。
3. 用 `sort` 找出最高分。
4. 写 `scripts/solve.sh`，生成 `results/summary.txt`。
5. 给脚本加执行权限，并用 `./scripts/solve.sh` 运行。
